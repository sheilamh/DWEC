//1.Crear un JavaScript que abra una ventana de alerta con un saludo

alert("Hola");