//3. Crear un JavaScript que nos muestra una alerta que tenga como mensaje un 1 al pichar sobre aceptar salga otro con el 2, así hasta 3. Realizarlo con bucles.
let i=1;
for(i=0; i<=2; i++){
    alert(i+1);
}