//2. Crear un JavaScript que pida dos números y los sume.

let n1 = prompt("Dime un numero");
let n2 = prompt("Dime otro numero");
let suma;
suma =parseInt(n1)+parseInt(n2);
alert("La suma de "+ n1 + " y "+ n2 + " es: "+suma);