//12.Escribir el código de una función a la que se pasa como parámetro un número entero y devuelve como resultado una cadena de texto que indica si el número es par o impar. 

let numero=6;

if (numero%2 == 0){
    alert("El numero es par");
}else alert("El numero es impar");