//4. Crear un JavaScript que muestre dos mensaje de alerta seguidos.

    alert("Hola");
    alert("Adios");
