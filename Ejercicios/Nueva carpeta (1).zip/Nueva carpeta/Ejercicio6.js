//6. Crear un JavaScript que nos pida una contraseña para acceder a una pagina, creada por ti.

let contrasena = prompt("Introduce la contraseña")
 
if (contrasena =="sheila"){
    window.location="eje6.html";
}
